import { ArrowRight, Play } from 'lucide-react';

const Hero = () => {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center pt-24 pb-section-mobile md:pb-section-desktop overflow-hidden"
    >
      {/* Background Image - commented out per request
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.pexels.com/photos/3757951/pexels-photo-3757951.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Luxury spa treatment"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-transparent"></div>
      </div>
      */}

      <div className="container-max px-6 md:px-8 relative z-10">
        <div className="max-w-2xl">
          {/* Section Label */}
          <div className="animate-fade-in">
            <span className="section-label">Premium Skincare Clinic</span>
          </div>

          {/* Headline */}
          <h1 className="section-title mt-4 mb-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
            Reveal Your Skin's Natural Radiance
          </h1>

          {/* Description */}
          <p className="text-lg md:text-xl text-paragraph/90 mb-8 leading-relaxed max-w-xl animate-fade-in" style={{ animationDelay: '0.2s' }}>
            Experience transformative skincare treatments designed by expert dermatologists.
            Your journey to luminous, healthy skin begins here.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-4 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <a href="#contact" className="btn-primary group">
              Start Your Journey
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </a>
            <a href="#about" className="btn-secondary group">
              <Play className="mr-2 w-5 h-5" />
              Watch Our Story
            </a>
          </div>

          {/* Trust Indicators */}
          <div className="mt-12 flex flex-wrap items-center gap-8 animate-fade-in" style={{ animationDelay: '0.4s' }}>
            <div className="text-center">
              <p className="text-3xl font-bold text-heading">15+</p>
              <p className="text-sm text-paragraph">Years Experience</p>
            </div>
            <div className="w-px h-12 bg-border hidden sm:block"></div>
            <div className="text-center">
              <p className="text-3xl font-bold text-heading">10k+</p>
              <p className="text-sm text-paragraph">Happy Clients</p>
            </div>
            <div className="w-px h-12 bg-border hidden sm:block"></div>
            <div className="text-center">
              <p className="text-3xl font-bold text-heading">50+</p>
              <p className="text-sm text-paragraph">Treatments</p>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fadeIn 0.6s ease-out forwards;
          opacity: 0;
        }
      `}</style>
    </section>
  );
};

export default Hero;
