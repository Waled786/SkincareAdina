import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';

const Footer = () => {
  const quickLinks = [
    { name: 'About Us', href: '#about' },
    { name: 'Treatments', href: '#products' },
    { name: 'Products', href: '#products' },
    { name: 'Testimonials', href: '#testimonials' },
    { name: 'Contact', href: '#contact' },
  ];

  const treatments = [
    { name: 'HydraFacial', href: '#' },
    { name: 'Anti-Aging', href: '#' },
    { name: 'Acne Solutions', href: '#' },
    { name: 'Chemical Peels', href: '#' },
    { name: 'Microdermabrasion', href: '#' },
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Youtube, href: '#', label: 'YouTube' },
  ];

  return (
    <footer className="bg-heading pt-section-mobile pb-8 md:pt-section-desktop">
      <div className="container-max px-6 md:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12 mb-16">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <a href="#home" className="inline-block mb-6">
              <span className="text-2xl font-bold text-white">
                Lumière<span className="text-primary">.</span>
              </span>
            </a>
            <p className="text-white/70 text-sm leading-relaxed mb-6">
              Premium skincare clinic dedicated to revealing your skin's natural radiance
              through expert care and innovative treatments.
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center
                           hover:bg-primary transition-colors duration-300"
                  aria-label={social.label}
                >
                  <social.icon className="w-4 h-4 text-white" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-white/70 hover:text-primary transition-colors duration-300 text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Treatments */}
          <div>
            <h3 className="text-white font-semibold mb-6">Treatments</h3>
            <ul className="space-y-3">
              {treatments.map((treatment, index) => (
                <li key={index}>
                  <a
                    href={treatment.href}
                    className="text-white/70 hover:text-primary transition-colors duration-300 text-sm"
                  >
                    {treatment.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold mb-6">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="text-white/70">123 Radiance Boulevard</li>
              <li className="text-white/70">Suite 500, Beverly Hills</li>
              <li className="text-white/70">CA 90210</li>
              <li className="mt-4">
                <a href="tel:+13105550123" className="text-white/70 hover:text-primary transition-colors duration-300">
                  +1 (310) 555-0123
                </a>
              </li>
              <li>
                <a href="mailto:hello@lumiereskin.com" className="text-white/70 hover:text-primary transition-colors duration-300">
                  hello@lumiereskin.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/50 text-sm">
              &copy; {new Date().getFullYear()} Lumière Skin Clinic. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-white/50 hover:text-white transition-colors duration-300">
                Privacy Policy
              </a>
              <a href="#" className="text-white/50 hover:text-white transition-colors duration-300">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
