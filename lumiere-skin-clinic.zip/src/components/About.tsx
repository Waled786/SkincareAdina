import { Award, Users, Heart, Leaf } from 'lucide-react';

const features = [
  {
    icon: Award,
    title: 'Award Winning',
    description: 'Recognized excellence in skincare innovation and customer satisfaction.',
  },
  {
    icon: Users,
    title: 'Expert Team',
    description: 'Board-certified dermatologists with decades of combined experience.',
  },
  {
    icon: Heart,
    title: 'Personalized Care',
    description: 'Customized treatment plans tailored to your unique skin needs.',
  },
  {
    icon: Leaf,
    title: 'Clean Ingredients',
    description: 'Ethically sourced, sustainable, and clinically proven formulations.',
  },
];

const About = () => {
  return (
    <section id="about" className="section-padding bg-white">
      <div className="container-max">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="relative aspect-[4/5] rounded-card overflow-hidden">
              <img
                src="https://images.pexels.com/photos/4162579/pexels-photo-4162579.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Dermatologist examining patient"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-6 -right-6 md:-right-8 bg-primary text-white p-6 md:p-8 rounded-2xl shadow-xl max-w-[200px]">
              <p className="text-4xl font-bold">15+</p>
              <p className="text-sm opacity-90">Years of Excellence in Skincare</p>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <span className="section-label">About Us</span>
            <h2 className="section-title mt-3 mb-6">
              Pioneering Excellence in Skincare Since 2009
            </h2>
            <p className="text-paragraph leading-relaxed mb-6">
              At Lumière Skin Clinic, we believe that radiant skin is not just about
              aesthetics—it's about confidence, health, and self-care. Our mission
              is to deliver transformative skincare experiences backed by science
              and delivered with compassion.
            </p>
            <p className="text-paragraph leading-relaxed mb-8">
              From cutting-edge treatments to our exclusive line of premium products,
              every service we offer is designed to help you achieve your skin goals
              in a luxurious, relaxing environment.
            </p>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-10 h-10 bg-hover rounded-lg flex items-center justify-center">
                    <feature.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-heading text-sm">{feature.title}</h3>
                    <p className="text-xs text-paragraph mt-1">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
