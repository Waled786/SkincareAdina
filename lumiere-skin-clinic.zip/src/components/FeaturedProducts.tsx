import { Star, ShoppingBag } from 'lucide-react';

interface Product {
  id: number;
  name: string;
  category: string;
  price: string;
  originalPrice: string;
  rating: number;
  reviews: number;
  image: string;
  badge?: string;
}

const products: Product[] = [
  {
    id: 1,
    name: 'Hydra-Luminous Serum',
    category: 'Serums',
    price: '$89',
    originalPrice: '$120',
    rating: 4.9,
    reviews: 324,
    image: 'https://images.pexels.com/photos/3641056/pexels-photo-3641056.jpeg?auto=compress&cs=tinysrgb&w=600',
    badge: 'Best Seller',
  },
  {
    id: 2,
    name: 'Renewal Night Cream',
    category: 'Night Care',
    price: '$75',
    originalPrice: '$95',
    rating: 4.8,
    reviews: 256,
    image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 3,
    name: 'Vitamin C Brightening',
    category: 'Treatments',
    price: '$65',
    originalPrice: '$85',
    rating: 4.9,
    reviews: 412,
    image: 'https://images.pexels.com/photos/4041390/pexels-photo-4041390.jpeg?auto=compress&cs=tinysrgb&w=600',
    badge: 'New',
  },
  {
    id: 4,
    name: 'Gentle Cleansing Oil',
    category: 'Cleansers',
    price: '$45',
    originalPrice: '$60',
    rating: 4.7,
    reviews: 189,
    image: 'https://images.pexels.com/photos/4041389/pexels-photo-4041389.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];

const ProductCard = ({ product }: { product: Product }) => {
  return (
    <div className="card group cursor-pointer p-0 overflow-hidden">
      {/* Product Image */}
      <div className="relative aspect-square overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        {product.badge && (
          <span className="absolute top-4 left-4 bg-primary text-white text-xs font-semibold px-3 py-1 rounded-full">
            {product.badge}
          </span>
        )}
        <button
          className="absolute bottom-4 right-4 bg-white p-3 rounded-full shadow-lg
                     opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0
                     transition-all duration-300 hover:bg-primary hover:text-white"
          aria-label="Add to cart"
        >
          <ShoppingBag size={18} />
        </button>
      </div>

      {/* Product Info */}
      <div className="p-6">
        <p className="text-sm text-paragraph/70 mb-1">{product.category}</p>
        <h3 className="text-lg font-semibold text-heading mb-2">{product.name}</h3>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-3">
          <Star className="w-4 h-4 fill-primary text-primary" />
          <span className="text-sm font-medium text-heading">{product.rating}</span>
          <span className="text-sm text-paragraph">({product.reviews} reviews)</span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold text-primary">{product.price}</span>
          <span className="text-sm text-paragraph/60 line-through">{product.originalPrice}</span>
        </div>
      </div>
    </div>
  );
};

const FeaturedProducts = () => {
  return (
    <section id="products" className="section-padding bg-background">
      <div className="container-max">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="section-label">Our Collection</span>
          <h2 className="section-title mt-3 mb-4">Featured Products</h2>
          <p className="text-paragraph max-w-2xl mx-auto">
            Discover our curated selection of premium skincare products,
            formulated with the finest ingredients for visible results.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <a href="#" className="btn-secondary">
            View All Products
          </a>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
