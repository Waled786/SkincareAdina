import { useState } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  content: string;
  rating: number;
  image: string;
  treatment: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Sarah Mitchell',
    role: 'Model & Influencer',
    content: 'Lumière transformed my skin completely. After just three sessions of their signature facial, my complexion has never looked better. The team truly understands luxury skincare.',
    rating: 5,
    image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=300',
    treatment: 'Signature HydraFacial',
  },
  {
    id: 2,
    name: 'Emily Chen',
    role: 'Business Executive',
    content: 'As someone with sensitive skin, I was nervous about trying new treatments. The dermatologists at Lumière were incredibly thorough and created a personalized plan that worked perfectly.',
    rating: 5,
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=300',
    treatment: 'Sensitive Skin Treatment',
  },
  {
    id: 3,
    name: 'Jessica Williams',
    role: 'Beauty Editor',
    content: 'I\'ve tried countless skincare clinics, but Lumière stands out. The attention to detail, premium products, and genuine care for results makes this my go-to destination.',
    rating: 5,
    image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=300',
    treatment: 'Anti-Aging Protocol',
  },
  {
    id: 4,
    name: 'Amanda Brooks',
    role: 'Wellness Coach',
    content: 'The whole experience at Lumière feels like a retreat. From the moment you walk in, you\'re treated with such care. My skin has improved dramatically thanks to their expert guidance.',
    rating: 5,
    image: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=300',
    treatment: 'Deep Rejuvenation Facial',
  },
];

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="section-padding bg-white overflow-hidden">
      <div className="container-max">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="section-label">Testimonials</span>
          <h2 className="section-title mt-3 mb-4">What Our Clients Say</h2>
          <p className="text-paragraph max-w-2xl mx-auto">
            Real stories from real clients who have experienced the
            Lumière difference.
          </p>
        </div>

        {/* Desktop Layout */}
        <div className="hidden lg:grid lg:grid-cols-3 gap-6">
          {testimonials.slice(0, 3).map((testimonial) => (
            <div key={testimonial.id} className="card">
              <Quote className="w-10 h-10 text-primary/20 mb-4" />
              <p className="text-paragraph leading-relaxed mb-6">{testimonial.content}</p>

              <div className="flex items-center gap-4 mt-auto">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                  loading="lazy"
                />
                <div>
                  <h4 className="font-semibold text-heading">{testimonial.name}</h4>
                  <p className="text-sm text-paragraph">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Mobile Slider */}
        <div className="lg:hidden relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="w-full flex-shrink-0 px-4">
                  <div className="card text-center max-w-md mx-auto">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-20 h-20 rounded-full object-cover mx-auto mb-4"
                      loading="lazy"
                    />
                    <div className="flex justify-center gap-1 mb-3">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                      ))}
                    </div>
                    <p className="text-paragraph leading-relaxed mb-4 text-sm">{testimonial.content}</p>
                    <h4 className="font-semibold text-heading">{testimonial.name}</h4>
                    <p className="text-sm text-paragraph">{testimonial.role}</p>
                    <span className="inline-block mt-2 text-xs bg-hover text-primary px-3 py-1 rounded-full">
                      {testimonial.treatment}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-center gap-4 mt-6">
            <button
              onClick={prevSlide}
              className="p-2 rounded-full border border-border hover:bg-primary hover:border-primary hover:text-white transition-all duration-300"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={nextSlide}
              className="p-2 rounded-full border border-border hover:bg-primary hover:border-primary hover:text-white transition-all duration-300"
              aria-label="Next testimonial"
            >
              <ChevronRight size={20} />
            </button>
          </div>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-4">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentIndex ? 'bg-primary w-6' : 'bg-border'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
