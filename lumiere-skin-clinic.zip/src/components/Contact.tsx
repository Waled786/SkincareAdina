import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Thank you for your inquiry! We will contact you shortly.');
    setFormData({ name: '', email: '', phone: '', service: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const contactInfo = [
    { icon: MapPin, label: 'Visit Us', value: '123 Radiance Boulevard, Suite 500, Beverly Hills, CA 90210' },
    { icon: Phone, label: 'Call Us', value: '+1 (310) 555-0123' },
    { icon: Mail, label: 'Email Us', value: 'hello@lumiereskin.com' },
    { icon: Clock, label: 'Hours', value: 'Mon-Sat: 9AM-7PM | Sun: 10AM-5PM' },
  ];

  return (
    <section id="contact" className="section-padding bg-background">
      <div className="container-max">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Contact Info */}
          <div>
            <span className="section-label">Get In Touch</span>
            <h2 className="section-title mt-3 mb-6">
              Book Your Consultation
            </h2>
            <p className="text-paragraph leading-relaxed mb-10">
              Ready to start your skincare journey? Reach out to schedule a
              complimentary consultation with one of our expert dermatologists.
            </p>

            {/* Contact Details */}
            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center flex-shrink-0">
                    <info.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-paragraph/70">{info.label}</p>
                    <p className="text-heading font-medium">{info.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-card rounded-card p-8 md:p-10 shadow-sm">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-heading mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background
                             focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none
                             transition-all duration-300"
                    placeholder="Jane Doe"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-heading mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background
                             focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none
                             transition-all duration-300"
                    placeholder="jane@example.com"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-heading mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background
                             focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none
                             transition-all duration-300"
                    placeholder="+1 (234) 567-8900"
                  />
                </div>

                <div>
                  <label htmlFor="service" className="block text-sm font-medium text-heading mb-2">
                    Service Interest
                  </label>
                  <select
                    id="service"
                    name="service"
                    value={formData.service}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background
                             focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none
                             transition-all duration-300"
                  >
                    <option value="">Select a service</option>
                    <option value="facial">Facial Treatment</option>
                    <option value="anti-aging">Anti-Aging</option>
                    <option value="acne">Acne Treatment</option>
                    <option value="hydration">Skin Hydration</option>
                    <option value="consultation">General Consultation</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-heading mb-2">
                  Your Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl border border-border bg-background
                           focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none
                           transition-all duration-300 resize-none"
                  placeholder="Tell us about your skin concerns..."
                />
              </div>

              <button type="submit" className="btn-primary w-full group">
                Send Message
                <Send className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
